import threading
import copy
from datetime import datetime, timedelta
from abc import ABC, abstractmethod

# 1. SINGLETON: Configuración de Reglas centralizada
class ConfiguracionReglas:
    _instancia = None
    def __new__(cls):
        if cls._instancia is None:
            cls._instancia = super(ConfiguracionReglas, cls).__new__(cls)
            cls._instancia.hora_limite_prioridad = 18
            cls._instancia.ventana_canc_estudiante = timedelta(hours=2)
            cls._instancia.ventana_canc_capitan = timedelta(hours=24)
            cls._instancia.limite_no_shows = 3
            cls._instancia.dias_suspension = timedelta(days=7)
        return cls._instancia

# ENTIDADES DEL MODELO DE DOMINIO
class Cancha:
    def __init__(self, id_cancha):
        self.id_cancha = id_cancha

class Solicitante:
    def __init__(self, id_solicitante, tipo):
        self.id_solicitante = id_solicitante
        self.tipo = tipo
        self.no_shows = 0
        self.fecha_suspension_fin = None

    def registrar_no_show(self, fecha_actual: datetime):
        self.no_shows += 1
        if self.no_shows >= ConfiguracionReglas().limite_no_shows:
            self.fecha_suspension_fin = fecha_actual + ConfiguracionReglas().dias_suspension

    def esta_suspendido(self, fecha_actual: datetime) -> bool:
        if self.fecha_suspension_fin and fecha_actual < self.fecha_suspension_fin:
            return True
        return False

# 2. STRATEGY (Regla de Prioridad convertida en clase)
class ReglaPrioridad(ABC):
    @abstractmethod
    def tiene_prioridad(self, solicitante: Solicitante) -> bool: pass

class PrioridadEquiposOficiales(ReglaPrioridad):
    def tiene_prioridad(self, solicitante: Solicitante) -> bool:
        return solicitante.tipo == "Capitan"

class PrioridadGeneral(ReglaPrioridad):
    def tiene_prioridad(self, solicitante: Solicitante) -> bool:
        return True

# 3. STRATEGY (Políticas de cancelación con cálculo real de tiempo)
class PoliticaCancelacion(ABC):
    @abstractmethod
    def calcular_estado(self, fecha_reserva: datetime, fecha_cancelacion: datetime) -> str: pass

class CancelacionEstudiante(PoliticaCancelacion):
    def calcular_estado(self, fecha_reserva, fecha_cancelacion):
        if fecha_reserva - fecha_cancelacion < ConfiguracionReglas().ventana_canc_estudiante:
            return "NO-SHOW"
        return "CANCELADA"

class CancelacionCapitan(PoliticaCancelacion):
    def calcular_estado(self, fecha_reserva, fecha_cancelacion):
        if fecha_reserva - fecha_cancelacion < ConfiguracionReglas().ventana_canc_capitan:
            return "NO-SHOW"
        return "CANCELADA"

class CancelacionAdmin(PoliticaCancelacion):
    def calcular_estado(self, fecha_reserva, fecha_cancelacion):
        return "ANULADA"

# ENTIDAD PRINCIPAL (Delega responsabilidades, no es anémica)
class Reserva:
    def __init__(self, cancha, fecha_hora, solicitante, sede_nombre, politica_canc):
        self.cancha = cancha
        self.fecha_hora = fecha_hora
        self.solicitante = solicitante
        self.sede_nombre = sede_nombre
        self.politica_canc = politica_canc
        self.estado = "CONFIRMADA"

    def cancelar(self, fecha_cancelacion: datetime):
        # La reserva aplica la norma internamente delegando al Strategy
        self.estado = self.politica_canc.calcular_estado(self.fecha_hora, fecha_cancelacion)
        if self.estado == "NO-SHOW":
            self.solicitante.registrar_no_show(fecha_cancelacion)

# 4. FACTORY METHOD
class ReservaFactory(ABC):
    @abstractmethod
    def crear_reserva(self, cancha, f_hora, sol, sede) -> Reserva: pass

class FabricaReservaEstudiante(ReservaFactory):
    def crear_reserva(self, cancha, f_hora, sol, sede):
        return Reserva(cancha, f_hora, sol, sede, CancelacionEstudiante())

class FabricaReservaCapitan(ReservaFactory):
    def crear_reserva(self, cancha, f_hora, sol, sede):
        return Reserva(cancha, f_hora, sol, sede, CancelacionCapitan())

# 5. ABSTRACT FACTORY (Sedes)
class ValidadorHorario(ABC):
    @abstractmethod
    def es_valido(self, hora: int) -> bool: pass

class Notificador(ABC):
    @abstractmethod
    def notificar(self, mensaje: str): pass

class SedeNorteFactory:
    def validador(self): return type('VN', (ValidadorHorario,), {'es_valido': lambda self, h: 6 <= h < 22})()
    def notificador(self): return type('NN', (Notificador,), {'notificar': lambda self, msg: print(f"[Email Norte] {msg}")})()

class SedeSurFactory:
    def validador(self): return type('VS', (ValidadorHorario,), {'es_valido': lambda self, h: 7 <= h < 23})()
    def notificador(self): return type('NS', (Notificador,), {'notificar': lambda self, msg: print(f"[SMS Sur] {msg}")})()

# 6. BUILDER (Recurrente Todo o Nada)
class BuilderReservaRecurrente:
    def __init__(self): self.reqs = {}
    def set_datos(self, c, f_inicio, s): self.reqs.update({'cancha':c, 'f_inicio':f_inicio, 'sol':s}); return self
    def set_semanas(self, semanas): self.reqs['semanas'] = semanas; return self
    def set_equipo(self, eq): self.reqs['equipo'] = eq; return self
    def get_peticion(self): return self.reqs

# 7. PROTOTYPE (Bloqueos)
class Bloqueo:
    def __init__(self, motivo, franja, equipo):
        self.motivo, self.franja, self.equipo = motivo, franja, equipo
    def clone(self, cancha, fecha):
        clon = copy.copy(self)
        clon.cancha, clon.fecha = cancha, fecha
        return clon

# 8. FACADE Y CONCURRENCIA
class ReservaFacade:
    def __init__(self):
        self.sedes = {"Norte": SedeNorteFactory(), "Sur": SedeSurFactory()}
        self.reservas = []
        self.lock = threading.Lock()

    def reservar(self, cancha: Cancha, fecha_hora: datetime, solicitante: Solicitante, id_sede: str, fecha_actual: datetime):
        sede = self.sedes[id_sede]
        if solicitante.esta_suspendido(fecha_actual):
            sede.notificador().notificar(f"Rechazo: {solicitante.id_solicitante} suspendido.")
            return False

        if not sede.validador().es_valido(fecha_hora.hour):
            sede.notificador().notificar("Fuera de horario permitido en la sede.")
            return False

        # Aplica Clase ReglaPrioridad
        if fecha_hora.hour < ConfiguracionReglas().hora_limite_prioridad:
            regla = PrioridadEquiposOficiales()
        else:
            regla = PrioridadGeneral()

        if not regla.tiene_prioridad(solicitante):
            sede.notificador().notificar("Rechazo: Horario requiere prioridad de Capitán.")
            return False

        # Sección Crítica Protegida
        with self.lock:
            for r in self.reservas:
                if r.cancha.id_cancha == cancha.id_cancha and r.fecha_hora == fecha_hora and r.estado == "CONFIRMADA":
                    sede.notificador().notificar("Rechazo: Cancha ya ocupada.")
                    return False
            
            fact = FabricaReservaEstudiante() if solicitante.tipo == "Estudiante" else FabricaReservaCapitan()
            reserva = fact.crear_reserva(cancha, fecha_hora, solicitante, id_sede)
            self.reservas.append(reserva)
            sede.notificador().notificar(f"Éxito: Reserva confirmada para {solicitante.id_solicitante}.")
            return True