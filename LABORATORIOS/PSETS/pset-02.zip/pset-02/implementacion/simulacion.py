import threading
import time
from datetime import datetime, timedelta
from patrones import ReservaFacade, Solicitante, Cancha, BuilderReservaRecurrente, Bloqueo

def ejecutar_simulacion():
    print("=== INICIANDO SIMULACIÓN PSET 2 (LÓGICA REAL) ===\n")
    facade = ReservaFacade()
    
    # Entidades base
    ahora = datetime(2026, 10, 15, 12, 0) # Fecha actual simulada
    cancha1 = Cancha("Cancha_Central")
    est1 = Solicitante("Juan", "Estudiante")
    cap1 = Solicitante("Messi", "Capitan")

    print("1. Reservas validadas por sede:")
    # Estudiante intenta a las 19:00 (Permitido)
    facade.reservar(cancha1, datetime(2026, 10, 20, 19, 0), est1, "Norte", ahora)
    
    print("\n2. Fuera de horario permitido:")
    # Estudiante intenta a las 05:00 en Campus Norte (Solo desde las 06:00)
    facade.reservar(cancha1, datetime(2026, 10, 21, 5, 0), est1, "Norte", ahora)

    print("\n3. Regla de Prioridad (<18:00 hrs):")
    facade.reservar(cancha1, datetime(2026, 10, 22, 14, 0), est1, "Sur", ahora) # Falla
    facade.reservar(cancha1, datetime(2026, 10, 22, 14, 0), cap1, "Sur", ahora) # Éxito

    print("\n4. Cancelaciones (Ejecución real de cálculo de tiempo en Strategy):")
    res_juan = facade.reservas[0]
    # Juan (Estudiante) cancela 1 hora antes del partido (Límite es 2h) -> NO-SHOW
    hora_canc_juan = res_juan.fecha_hora - timedelta(hours=1)
    res_juan.cancelar(hora_canc_juan)
    print(f"Estado reserva Juan: {res_juan.estado} | No-shows actuales: {est1.no_shows}")

    res_messi = facade.reservas[1]
    # Messi (Capitán) cancela 10 horas antes del partido (Límite es 24h) -> NO-SHOW
    hora_canc_messi = res_messi.fecha_hora - timedelta(hours=10)
    res_messi.cancelar(hora_canc_messi)
    print(f"Estado reserva Messi: {res_messi.estado} | No-shows actuales: {cap1.no_shows}")

    print("\n5. Suspensión Automática por 3 No-shows:")
    est1.registrar_no_show(ahora)
    est1.registrar_no_show(ahora) 
    facade.reservar(cancha1, datetime(2026, 10, 25, 19, 0), est1, "Norte", ahora)

    print("\n6. Bloqueo Clonado (Prototype):")
    plantilla = Bloqueo("Torneo", "10:00-14:00", "Conos")
    b1 = plantilla.clone(cancha1, datetime(2026, 10, 30))
    print(f"Bloqueo instanciado para {b1.cancha.id_cancha} con motivo '{b1.motivo}' y equipo '{b1.equipo}'.")

    print("\n7. Concurrencia (Doble petición simultánea controlada por Lock):")
    def intentar_reserva(nombre):
        time.sleep(0.1)
        temp_user = Solicitante(nombre, "Capitan")
        facade.reservar(cancha1, datetime(2026, 11, 1, 10, 0), temp_user, "Sur", ahora)

    t1 = threading.Thread(target=intentar_reserva, args=("Hilo_1",))
    t2 = threading.Thread(target=intentar_reserva, args=("Hilo_2",))
    t1.start(); t2.start()
    t1.join(); t2.join()

if __name__ == "__main__":
    ejecutar_simulacion()